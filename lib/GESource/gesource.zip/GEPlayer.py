################ Copyright 2005-2013 Team GoldenEye: Source #################
#
# This file is part of GoldenEye: Source's Python Library.
#
# GoldenEye: Source's Python Library is free software: you can redistribute 
# it and/or modify it under the terms of the GNU General Public License as 
# published by the Free Software Foundation, either version 3 of the License, 
# or(at your option) any later version.
#
# GoldenEye: Source's Python Library is distributed in the hope that it will 
# be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General 
# Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with GoldenEye: Source's Python Library.
# If not, see <http://www.gnu.org/licenses/>.
#############################################################################
import GEEntity, GEWeapon

def IsValidPlayerIndex( index ):
	'''
	@type index: int
	'''
	return bool

class CBaseCombatCharacter( GEEntity.CBaseEntity ):
	def GetHealth( self ):
		return int

	def SetHealth( self, health ):
		'''
		@type health: int
		'''
		pass

	def GetSkin( self ):
		return int

	def GetActiveWeapon( self ):
		return GEWeapon.CGEWeapon

	def HasWeapon( self, weapon ):
		'''
		Check if the player has the weapon in question.
		You can pass in a valid weapon id, weapon classname, 
		or weapon entity
		
		@type weapon: int, str, or GEWeapon.CGEWeapon
		'''
		return bool

	def WeaponSwitch( self, weapon ):
		'''
		Switch to the given weapon. You can pass in a valid weapon id,
		weapon classname, or weapon entity this entity owns
		
		@type weapon: int, str, or GEWeapon.CGEWeapon
		'''
		return bool

	def GetAmmoCount( self, weapon_or_ammo ):
		'''
		Returns the amount of ammo held by the player. This function
		can be called with weapon_or_ammo set to a weapon entity,
		weapon id, or ammo name (see GEGlobal).
		
		@type weapon_or_ammo: int, str, or GEWeapon.CGEWeapon
		'''
		return int

	def GetHeldWeapons( self ):
		'''
		Returns a list of weapon entities held by the player
		'''
		return []

	def GetHeldWeaponIds( self ):
		'''
		Returns a list of weapon ids held by the player
		'''
		return []

def ToCombatCharacter( ent ):
	'''
	@type ent: GEEntity.CBaseEntity
	'''
	return CBaseCombatCharacter

class CGEPlayer( CBaseCombatCharacter ):
	def GetFrags( self ):
		return int

	def GetDeaths( self ):
		return int

	def AddDeathCount( self, amount ):
		'''
		@type amount: int
		'''
		pass

	def GetArmor( self ):
		return int

	def GetHealth( self ):
		return int

	def ResetDeathCount( self ):
		return

	def CommitSuicide( self ):
		'''
		Force the player to commit suicide, counts against them
		'''
		return

	def GetPlayerName( self ):
		'''
		Get the player's name (includes color hints)
		'''
		return str

	def GetPlayerID( self ):
		'''
		Get the player's id (useful for event messages)
		'''
		return int

	def GetSteamID( self ):
		'''
		Get the player's Steam ID. If they are on LAN or offline this will ALWAYS
		return "STEAM_ID_PENDING". Use this for identification carefully.
		
		Note: Bots don't have a Steam ID!!
		'''
		return str

	def IsDead( self ):
		return bool

	def IsObserver( self ):
		return bool

	def GetMaxArmor( self ):
		return int

	def SetMaxArmor( self ):
		return int

	def GetMaxHealth( self ):
		return int

	def SetMaxHealth( self ):
		return int

	def SetArmor( self, armor ):
		'''
		@type armor: int
		'''
		pass

	def GetPlayerModel( self ):
		'''
		Identity of the player's character
		'''
		return str

	def SetPlayerModel( self, character, skin ):
		'''
		Set the player's character & skin explicitly 
		
		@type character: string
		@type skin: int
		'''
		pass

	def SetDamageMultiplier( self, mult ):
		'''
		Multiplier for damage inflicted by this player [0-200]
		
		@type mult: int
		'''
		pass

	def SetSpeedMultiplier( self, mult ):
		'''
		Multiplier for the player's speed [0.5-1.5]
		
		@type mult: int
		'''
		pass

	def SetScoreBoardColor( self, color ):
		'''
		Sets the color of the player's name in the scoreboard
		Use GEGlobal.SB_COLOR_* for the colors
		
		@type color: int
		'''
		pass

	def StripAllWeapons( self ):
		'''
		Take all weapons and ammo from the player
		'''
		return

	def GetAimDirection( self ):
		'''
		Returns the current vector pointing in the direction the player is aiming
		Note: Currently does not work for bots
		'''
		return GEUtil.Vector

	def GetEyePosition( self ):
		'''
		Returns the current position of this player's eyes
		'''
		return GEUtil.Vector

	def GiveNamedWeapon( self, classname, ammo_amt, strip_ammo=False ):
		'''
		If strip_ammo is True it will only give ammo_amt to the player and not
		the default clip ammo of the weapon
		
		@type classname: string
		@type ammo_amt: int
		@type strip_ammo: boolean
		'''
		pass

class CGEMPPlayer( CGEPlayer ):
	def GetRoundScore( self ):
		return int

	def SetRoundScore( self, score ):
		'''
		@type score: int
		'''
		pass

	def AddRoundScore( self, amount ):
		'''
		@type amount: int
		'''
		pass

	def ResetRoundScore( self ):
		return

	def GetMatchScore( self ):
		return int

	def SetMatchScore( self, score ):
		'''
		@type score: int
		'''
		pass

	def AddMatchScore( self, amount ):
		'''
		@type amount: int
		'''
		pass

	def SetDeaths( self, deaths ):
		'''
		@type deaths: int
		'''
		pass

	def ForceRespawn( self ):
		'''
		Forces the player to find a new spawn spot, does not count
		negatively against their score like a suicide would
		'''
		return

	def ChangeTeam( self, team, forced=False ):
		'''
		Force the player to change to the specified team, if forced it will
		not count against the player in scores
		
		@type team: int
		@type forced: boolean
		'''
		pass

	def GetCleanPlayerName( self ):
		'''
		Return the player's name without color hints, useful for
		on-screen notifications
		'''
		return str

	def IsInitialSpawn( self ):
		'''
		Is this the first spawn for the player in the match?
		'''
		return bool

	def SetInitialSpawn( self, state ):
		'''
		Explicitly set the next spawn for this player as initial
		
		@type state: boolean
		'''
		pass
		
	def IsInRound( self ):
		'''
		NOT spectating, have selected a character (i.e., not in pre-spawn),
		and are NOT blocked from respawning by the scenario.
		'''
		return bool
		
	def IsActive( self ):
		'''
		NOT an observer or spectating.
		'''
		return bool
		
	def IsPreSpawn( self ):
		'''
		Joined server and have NOT selected a character.
		'''
		return bool

	def GiveDefaultWeapons( self ):
		'''
		Gives the player the default weapon loadout as if they spawned
		'''
		return

	def GiveAmmo( self, ammo_name, amount, suppress_sound=False ):
		'''
		@type ammo_name: string
		@type amount: int
		@type suppress_sound: boolean
		'''
		pass

def ToMPPlayer( ent_or_uid ):
	'''
	Returns an MP Player instance if supplied an entity instance or player's unique id
	Returns None if conversion fails or entity does not exist

	@type ent: GEEntity.CBaseEntity or Unique ID of player
	'''
	return CGEMPPlayer

def GetMPPlayer( index ):
	'''
	Returns an MP Player instance if supplied a valid player entity index (1 -> maxplayers)
	Return None if the player does not exist

	@type index: int
	'''
	return CGEMPPlayer

class CGEBotPlayer( CGEMPPlayer ):
	def GiveNamedWeapon( self, classname, ammo_amt, strip_ammo=False ):
		'''
		@type classname: string
		@type ammo_amt: int
		@type strip_ammo: boolean
		'''
		pass

	def ChangeTeam( self, team, forced=False ):
		'''
		@type team: int
		@type forced: boolean
		'''
		pass

	def StripAllWeapons( self ):
		return

