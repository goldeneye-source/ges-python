################ Copyright 2005-2013 Team GoldenEye: Source #################
#
# This file is part of GoldenEye: Source's Python Library.
#
# GoldenEye: Source's Python Library is free software: you can redistribute 
# it and/or modify it under the terms of the GNU General Public License as 
# published by the Free Software Foundation, either version 3 of the License, 
# or(at your option) any later version.
#
# GoldenEye: Source's Python Library is distributed in the hope that it will 
# be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General 
# Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with GoldenEye: Source's Python Library.
# If not, see <http://www.gnu.org/licenses/>.
#############################################################################
class CGamePlayManager:
	pass

def GetScenario():
	'''Get the current active scenario, useful for specialty NPC'''
	return CBaseScenario

class CBaseScenario:
	def GetIdent( self ):
		return str

	def CreateCVar( self, name, def_value, help_str ):
		'''
		Create a console variable that can be set by config scripts
		or directly in the console by the server owner.
		
		@type name: str
		@type def_value: str
		@type help_str: str
		'''
		return

	def ShowScenarioHelp( self, player, pane_id_or_key ):
		'''
		Show the specified help pane (must be pre-registered) to the player
		
		@type player: GEPlayer.CGEMPPlayer
		@type pane_id_or_key: str or int
		'''
		return

class CScenarioHelp:
	def SetInfo( self, tagline, website ):
		'''
		Set the tagline and website for this scenario. Users can click the website
		to see advanced help details.
		
		@type tagline: str
		@type website: str
		'''
		return

	def SetDescription( self, description ):
		'''
		Set the overall description for this scenario, this is shown in the
		popup help box at the bottom of the screen.
		
		@type description: str
		'''
		return

	def SetDefaultPane( self, pane_key ):
		'''
		Sets the pane that will be shown when the player connects to the server
		
		@type pane_key: int
		'''
		return

	def AddPane( self, id ):
		'''
		Creates a pane that you can add help items too, returns the pane key.
		The id must be a unique string from your other help panes, it is used
		to allow players to disable this help pane from showing in the future.
		It is useful to store the pane key or id for use later in showing 
		the help and adding help items to the pane.
		
		@type id: str
		'''
		return int

	def AddHelp( self, pane_key, image, description ):
		'''
		Adds a help item to the specified pane, you may pass localized variables
		to the description. Image is simply a filename entry with the actual image
		must be stored in "materials/vgui/hud/gameplayhelp/".
		
		@type pane_key: int
		@type image: str
		@type description: str
		'''
		return
